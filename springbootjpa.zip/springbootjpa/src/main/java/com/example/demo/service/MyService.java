package com.example.demo.service;

import java.util.List;

import com.example.demo.bean.Cars;

public interface MyService {

	public List<Cars> getAllCars();
	
	public boolean addCar(Cars car);
	
	public List<Cars> getAllCarsByManufac(String manufacID);

	public boolean addUpdate(Cars car);
}
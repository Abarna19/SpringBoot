package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Cars;
import com.example.demo.repository.MyJPARepository;

@Service
public class MyServiceImpl implements MyService
{

	@Autowired
	MyJPARepository repo;
	
	@Override
	public List<Cars> getAllCars() {
		
		return repo.findAll();
	}

	@Override
	public boolean addCar(Cars car) {
		
		 repo.save(car);
		 return true;
	}

	@Override
	public List<Cars> getAllCarsByManufac(String manufacID) {
		
		return repo.findByManufac(manufacID);
	}

	@Override
	public boolean addUpdate(Cars car) {
		// TODO Auto-generated method stub
		repo.update(car);
		return true;
		
	}

}